using FinanceTracker.Core.ViewModels;

namespace FinanceTracker.MAUI.Views;

public partial class CategoriesPage : ContentPage
{

    public CategoriesPage()
    {
        InitializeComponent();
    }
    protected override void OnAppearing()
    {
        base.OnAppearing();

    //Content = new Label
    //{
    //    Text = "CODE-BEHIND WORKS",
    //    FontSize = 30,
    //    TextColor = Colors.Red
    //};


        if (BindingContext == null)
            BindingContext = App.Services.GetRequiredService<CategoriesViewModel>();
    }
}
